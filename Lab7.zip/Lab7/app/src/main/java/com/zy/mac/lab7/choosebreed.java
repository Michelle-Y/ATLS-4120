package com.zy.mac.lab7;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class choosebreed extends AppCompatActivity {
    private catinfo breeds = new catinfo();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_breed);

        Intent intent = getIntent();
        final Button button = (Button) findViewById(R.id.button);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                sendBackInfo(view);
            }
        };
        button.setOnClickListener(onclick);

    }
    public void sendBackInfo(View view){
        Spinner catchoice = (Spinner)findViewById(R.id.spinner);
        int catnum = catchoice.getSelectedItemPosition();
        breeds.getcatinfo(catnum);
        int catImageName = breeds.getImagecat();
        String catinformation =breeds.getDescription();

        Intent intentBack = new Intent(this, MainActivity.class);

        intentBack.putExtra("catima", catImageName);
        intentBack.putExtra("Description", catinformation);

        startActivity(intentBack);
    }
    public void googleBreeds(View view){
        Spinner catchoice = (Spinner)findViewById(R.id.spinner);
        int catnum = catchoice.getSelectedItemPosition();
        Intent intent = new Intent(Intent.ACTION_VIEW);
        switch (catnum){
            case 0:
                intent.setData(Uri.parse("https://en.wikipedia.org/wiki/Abyssinian_cat"));
                break;
            case 1:
                intent.setData(Uri.parse("https://en.wikipedia.org/wiki/American_Shorthair"));
                break;
            case 2:
                intent.setData(Uri.parse("https://en.wikipedia.org/wiki/Bengal_cat"));
                break;
            case 3:
                intent.setData(Uri.parse("https://en.wikipedia.org/wiki/British_Shorthair"));
                break;
            case 4:
                intent.setData(Uri.parse("https://en.wikipedia.org/wiki/Peterbald"));
                break;
            case 5:
                intent.setData(Uri.parse("https://en.wikipedia.org/wiki/Ragdoll"));
                break;
            case 6:
                intent.setData(Uri.parse("https://en.wikipedia.org/wiki/Siamese_cat"));
                break;
            case 7:
                intent.setData(Uri.parse("https://en.wikipedia.org/wiki/Siberian_cat"));
                break;

        }
        startActivity(intent);
    }
}
