package com.zy.mac.lab7;

public class catinfo {
    private  int imagecat;
    private String description;

    public void getcatinfo(int id) {
        switch (id) {
            case 0:
                imagecat = 0;
                description = "Abyssinian cats look like a small mountain lion or cougar with almond eyes set in a dramatically marked expressive face and they are athletic, alert and very active. Even though they are well-muscled their movement is lithe, graceful and very quick.";
                break;
            case 1:
                imagecat = 1;
                description = "The American Shorthair is the pedigreed version of the well-known and beloved domestic shorthair. This versatile cat can be bred for any number of colors and patterns, including the popular silver tabby. They are easygoing and tolerant. ";
                break;
            case 2:
                imagecat = 2;
                description = "The Bengal is a domestic cat breed developed to look like exotic wild cats such as leopards, ocelots, margays and clouded leopards.";
                break;
            case 3:
                imagecat = 3;
                description = "The British Shorthair is solid and muscular with an easygoing personality. As befits his British heritage, he is slightly reserved, but once he gets to know someone he’s quite affectionate. His short, dense coat comes in many colors and patterns.";
                break;
            case 4:
                imagecat = 4;
                description = "The peterbald is an elegant Russian breed with a unique coat. The cats may be totally hairless, or they may have a coat that looks and feels like a peach. The peterbald is a medium sized cat, with a body shape similar to the oriental shorthair, but more muscular. ";
                break;
            case 5:
                imagecat = 5;
                description = "His floppy, relaxed good nature gives the Ragdoll his name. He is a big, gentle cat with striking blue eyes who can get along with everyone, including other animals, traits that make him adaptable to almost any home. ";
                break;
            case 6:
                imagecat = 6;
                description = "The Siamese cat is one of the first distinctly recognized breeds of Asian cat. Derived from the Wichianmat landrace, one of several varieties of cat native to Thailand (formerly known as Siam).";
                break;
            case 7:
                imagecat = 7;
                description = "Siberians are medium to large, strong and sturdy cats. They are muscular felines who have large, rounded, powerful paws. ";
                break;
//            default:
//                imagecat = 8;
//                description = "Choose breed!";
        }
    }

    public void setImagecat(int image){
        imagecat = image;
    }
    public void setDescription(String message){
        description = message;
    }
    public int getImagecat(){
        return imagecat;
    }
    public String getDescription(){
        return description;
    }
}
