package com.zy.mac.lab7;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private int catima;
    private String description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        if(intent.getExtras() != null){
            catima = intent.getIntExtra("catima", 0);
            description = intent.getStringExtra("Description");
            setView();
        }
        final Button search = (Button) findViewById(R.id.search);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                startResearching(view);
            }
        };
        search.setOnClickListener(onclick);
    }
    public void startResearching(View view){
        Intent intent = new Intent(this, choosebreed.class);
        startActivity(intent);
    }
    public void setView(){
        TextView desc = (TextView) findViewById(R.id.textView3);
        desc.setText(description);
        ImageView catImage = (ImageView) findViewById(R.id.imageView);
//        Spinner catchoice = (Spinner)findViewById(R.id.spinner);
//        catima = catchoice.getSelectedItemPosition();
//        catImage.setImageResource(R.drawable.toppage);
        switch (catima){
            case 0:
                catImage.setImageResource(R.drawable.abyssiniancat);
                break;
            case 1:
                catImage.setImageResource(R.drawable.americanshorthair);
                break;
            case 2:
                catImage.setImageResource(R.drawable.bengal);
                break;
            case 3:
                catImage.setImageResource(R.drawable.britishshorthair);
                break;
            case 4:
                catImage.setImageResource(R.drawable.peterbald);
                break;
            case 5:
                catImage.setImageResource(R.drawable.ragdoll);
                break;
            case 6:
                catImage.setImageResource(R.drawable.siamese);
                break;
            case 7:
                catImage.setImageResource(R.drawable.siberiancat);
                break;
//            default:
//                catImage.setImageResource(R.drawable.toppage);
        }
    }
}
