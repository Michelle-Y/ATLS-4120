package com.zy.mac.afinal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

public class newPageActivity extends AppCompatActivity {
    private String feedback;
    private String placeURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpage);
        //get intent
        Intent intent = getIntent();
        feedback = intent.getStringExtra("result");
        placeURL = "https://bossladypizza.com";

        //update text view
        TextView messageView = (TextView) findViewById(R.id.resultTextView);
        messageView.setText("You should check out " + feedback);

        //get button
        final Button searchButton = (Button) findViewById(R.id.searchButton);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }
        };

        //add listener to the button
        searchButton.setOnClickListener(onclick);

    }
    public void loadWebSite(View view){
//        RadioGroup cost = (RadioGroup) findViewById(R.id.radioGroup2);
//        int cost_id = cost.getCheckedRadioButtonId();
//        Switch gluten = (Switch) findViewById(R.id.switch2);
//        boolean glutenFree = gluten.isChecked();
        Intent intent = new Intent(Intent.ACTION_VIEW);
//        if (cost_id == R.id.radioButton4) {
//            placeURL = "https://localeboulder.com";
//        }else if (cost_id == R.id.radioButton2){
//            placeURL = "https://backcountrypizzaandtaphouse.info";
//        }
//        if (glutenFree){
//            placeURL = "https://bossladypizza.com";
//        }
        intent.setData(Uri.parse(placeURL));
        startActivity(intent);
    }
}
