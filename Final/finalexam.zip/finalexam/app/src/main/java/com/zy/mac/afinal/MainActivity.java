package com.zy.mac.afinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View.OnClickListener onclick1 = new View.OnClickListener() {
            public void onClick(View view) {
                viewInNewWindow(view);
            }
        };
        View.OnClickListener onclick = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                generateFood(view);
            }
        };
        Button submit = (Button) findViewById(R.id.submit);
        Button button3 = (Button) findViewById(R.id.button3);
        submit.setOnClickListener(onclick);
        button3.setOnClickListener(onclick1);
//    submit.OnClickListener(onclick);

    }

    public void viewInNewWindow(View view) {
        String restaurant = "";

        //radio buttons
        RadioGroup cost = (RadioGroup) findViewById(R.id.radioGroup2);
        int cost_id = cost.getCheckedRadioButtonId();
        if (cost_id == R.id.radioButton4){
            restaurant = "Old Chicago";
        }else if (cost_id == R.id.radioButton2){
            restaurant = "Pizzeria Locale";
        }
        // switch
        Switch gluten = (Switch) findViewById(R.id.switch2);
        boolean glutenFree = gluten.isChecked();
        if (glutenFree){
            restaurant = "Boss Lady";
        }

        Intent intent = new Intent(this, newPageActivity.class);
        intent.putExtra("result", restaurant);

        startActivity(intent);
    }

    public void generateFood(View view) {
        String whiteOrRed = "";
        String restaurant = "";
        String sizeText = "";
        String supremeText = "";
        String veggieText = "";
        String meatText = "";
        String cheeseText = "";
        String thinOrThick = "";
        String isGlutenFree = "";

        EditText e = findViewById(R.id.editText);
        String name = e.getText().toString();

        TextView PizzaDetailTextView = (TextView) findViewById(R.id.textView2);

        //check boxes
        CheckBox cheeseCheckBox = (CheckBox) findViewById(R.id.checkBox2);
        Boolean cheese = cheeseCheckBox.isChecked();

        CheckBox veggieCheckBox = (CheckBox) findViewById(R.id.checkBox3);
        Boolean veggie = veggieCheckBox.isChecked();

        CheckBox supremeCheckBox = (CheckBox) findViewById(R.id.checkBox);
        Boolean supreme = supremeCheckBox.isChecked();

        CheckBox meatCheckBox = (CheckBox) findViewById(R.id.checkBox4);
        Boolean meat = meatCheckBox.isChecked();

        //toggle button
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean toggleSauce = toggle.isChecked();

        //spinner
        Spinner siz = (Spinner) findViewById(R.id.spinner3);
        String size = String.valueOf(siz.getSelectedItem());

        //radio buttons
        RadioGroup cost = (RadioGroup) findViewById(R.id.radioGroup2);
        int cost_id = cost.getCheckedRadioButtonId();

        // switch
        Switch gluten = (Switch) findViewById(R.id.switch2);
        boolean glutenFree = gluten.isChecked();
        //thin or thick
        if (cost_id == R.id.radioButton4){
            thinOrThick = "thick";
            restaurant = "Old Chicago";
        }else if(cost_id == R.id.radioButton2){
            thinOrThick = "thin";
            restaurant = "Pizzeria Locale";
        }
        //image checkbox
        if(supreme){
            setImage(1);
        }else if(cheese){
            setImage(2);
        }else if(veggie){
            setImage(4);
        }else if(meat){
            setImage(3);
        }

        // red vs. white
        if (toggleSauce) {
            whiteOrRed = "White";
        } else {
            whiteOrRed = "Red";
        }

        // Get size
        switch (size) {
            case "Small":
                sizeText = "small";
                break;
            case "Medium":
                sizeText = "medium";
                break;
            case "Large":
                sizeText = "large";
                break;
        }

        // Get toppings
        if (supreme) {
            supremeText = " supreme ";
        }
        if (cheese) {
            cheeseText = " cheese ";
        }
        if (veggie) {
            veggieText = " veggie ";
        }
        if (meat) {
            meatText = " meat ";
        }

        // gluten free
        if (glutenFree) {
            isGlutenFree = " gluten free ";
            restaurant = "Boss Lady";
        }

        PizzaDetailTextView.setText("The " + name + " is a " + sizeText + " " + thinOrThick + " crust " + isGlutenFree + " pizza with " + whiteOrRed + " sauce and " +
                supremeText + meatText + veggieText + cheeseText + "." + "\n"   + "The suggested restaurant is " + restaurant + ".");
    }

    private void setImage(int val) {
        ImageView i = (ImageView) findViewById(R.id.imageView);
        i.setVisibility(View.VISIBLE);
        if (val == 1) {
            i.setImageResource(R.drawable.pizza_supreme);
        }else if (val == 2) {
            i.setImageResource(R.drawable.pizza_cheese);
        }else if (val == 3) {
            i.setImageResource(R.drawable.pizza_meat);
        }else if (val == 4) {
            i.setImageResource(R.drawable.pizza_veggie);
        }
    }
}
