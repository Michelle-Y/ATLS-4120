package com.Interface;


public interface finalName_NoteListView {
    int NOTE = 1;
    int NOTE_ADD = 1, NOTE_MODIFY = 2;
    int STAR_NO = 0 ,STAR_RED = 1 ,STAR_GOLD = 2 ,STAR_BLUE = 3 ;
    int TYPE_CONTENT = 0 ,TYPE_DATE = 1 ,TYPE_LABEL=2;
}
