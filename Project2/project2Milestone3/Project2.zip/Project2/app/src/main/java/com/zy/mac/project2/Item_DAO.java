package com.zy.mac.project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.zy.mac.project2.MyDBHelper;
import com.zy.mac.project2.Note_item;

import java.util.ArrayList;
import java.util.List;

public class Item_DAO {
    public MyDBHelper myDBHelper;
    public static final String TABLE_NAME = "item";
    public static final String KEY_ID = "_id";

    public static final String DATETIME = "datetime";               //long
    public static final String LASTMODIFY = "lastModify";           //long
    public static final String TITLE = "title";                     //string
    public static final String CONTENT = "content";                 //string
    public static final String LABEL = "label";                     //string
    public static final String PICTURE = "picture";                 //byte[]

    public static final String PICTURE_EX = "picture_ex";           //string

    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" + KEY_ID +" INTEGER PRIMARY KEY AUTOINCREMENT, "+
                    DATETIME + " INTEGER, " +
                    LASTMODIFY + " INTEGER, " +
                    TITLE + " TEXT, " +
                    CONTENT + " TEXT, " +
                    LABEL + " TEXT," +
                    PICTURE + " BLOB,"+
                    PICTURE_EX + " TEXT)";

    private SQLiteDatabase db;

    public Item_DAO(Context context) {
        // call database
        if ( db == null || !db.isOpen() ){
            myDBHelper= new MyDBHelper(context);
            db = myDBHelper.getWritableDatabase();
        }
    }

    public void close() {
        db.close();
    }

    // Add new staff
    public Note_item insert(Note_item item){
        ContentValues cv = new ContentValues();

        // what'sfor， information
        cv.put(DATETIME, item.getDatetime());
        cv.put(LASTMODIFY, item.getLastModify());
        cv.put(TITLE, item.getTitle());
        cv.put(CONTENT, item.getContent());
        cv.put(LABEL, item.getLabel());
        cv.put(PICTURE, item.getPicture());
        cv.put(PICTURE_EX, item.getPicture_ex());

        long id = db.insert(TABLE_NAME, null, cv);

        item.setId(id);
        return item;
    }
    // update items
    public boolean update(Note_item item){
        ContentValues cv = new ContentValues();

        cv.put(DATETIME, item.getDatetime());
        cv.put(LASTMODIFY, item.getLastModify());
        cv.put(TITLE, item.getTitle());
        cv.put(CONTENT, item.getContent());
        cv.put(LABEL, item.getLabel());
        cv.put(PICTURE, item.getPicture());
        cv.put(PICTURE_EX, item.getPicture_ex());

        // more clearly idforculumn+iditem
        String where = KEY_ID + "=" + item.getId();

        // succss>0 fail:-1
        return db.update(TABLE_NAME, cv, where, null) > 0;
    }

    public boolean delete(Note_item item){
        String where = KEY_ID + "=" + item.getId();

        // succss>0 fail:-1
        return db.delete(TABLE_NAME, where, null) > 0;
    }

    public Note_item getRecord(Cursor cursor) {
        Note_item result = new Note_item();

        result.setId(cursor.getLong(0));
        result.setDatetime(cursor.getLong(1));
        result.setLastModify(cursor.getLong(2));
        result.setTitle(cursor.getString(3));
        result.setContent(cursor.getString(4));
        result.setLabel(cursor.getString(5));
        result.setPicture(cursor.getBlob(6));
        result.setPicture_ex(cursor.getString(7));

        return result;
    }


    public List<Note_item> get_sortDate(){
        List<Note_item> result = new ArrayList<>();

        Cursor cur = db.rawQuery("select * from " +TABLE_NAME+" order by "+DATETIME +" desc,"+ TITLE +";",null);
        while(cur.moveToNext()){
            result.add(getRecord(cur));
        }
        cur.close();
        return result;
    }

    public int getAll_Count() {
        int result = 0;
        Cursor cursor = db.rawQuery("select count(*) from " + TABLE_NAME, null);

        if (cursor.moveToNext()) {
            result = cursor.getInt(0);
        }
        cursor.close();
        return result;
    }
}
