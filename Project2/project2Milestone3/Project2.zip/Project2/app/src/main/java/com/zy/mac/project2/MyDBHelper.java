package com.zy.mac.project2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.zy.mac.project2.Item_DAO;


public class MyDBHelper extends SQLiteOpenHelper {
    //public Item_DAO itemDAO;

    // name database
    public static final String DATABASE_NAME = "My_Database";
    public static final int VERSION = 1;

    public MyDBHelper(Context context) {
        super(context, DATABASE_NAME, null,VERSION );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //  public input
        db.execSQL(Item_DAO.CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // delete original
        db.execSQL("DROP TABLE IF EXISTS" + Item_DAO.TABLE_NAME);
        // create new
        onCreate(db);
    }
}
