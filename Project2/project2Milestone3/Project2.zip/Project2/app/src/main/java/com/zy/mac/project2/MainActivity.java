package com.zy.mac.project2;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.ListViewCompat;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.Interface.finalName_NoteListView;
import com.zy.mac.project2.ItemAdapter;
import com.zy.mac.project2.Item_DAO;
import com.zy.mac.project2.New_noteActivity;
import com.zy.mac.project2.Note_item;
import com.zy.mac.project2.Other_way;
import com.zy.mac.project2.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements finalName_NoteListView {
    private Other_way Other = new Other_way();
    private Item_DAO itemDAO;
    private Menu changeMenu;
    private TextView choice_number;
    private FloatingActionButton fab;
    private DrawerLayout drawer;
    private ItemAdapter itemAdapter;
    private ListViewCompat listView_notes;

    private boolean long_listener=false , selectClick=false ,is_search=false , search_to_select=false;
    private int choice_count;
    private int sortWay;
    private final int changeTitle=2 ,changeLabel =3 ,changeDatetime=4;
    private final int sort_date=1;


    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        define_views();
        initial();
        click_short_Listener();
        click_long_Listener();
    }

    public void define_views(){
        listView_notes = (ListViewCompat)findViewById(R.id.listView_all_notes);
        choice_number=(TextView)findViewById(R.id.textView_number);

        fab = (FloatingActionButton) findViewById(R.id.fab);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    public void initial(){
        itemDAO = new Item_DAO(this);
        itemAdapter = new ItemAdapter(this);

        choice_count=0;
        sortWay = sort_date;
        List<Note_item> list_item = itemDAO.get_sortDate();
        for(int i=0 ; i< list_item.size() ; i++){
            itemAdapter.add(list_item.get(i) ,TYPE_DATE);
        }
        itemAdapter.notifyDataSetChanged();
        list_item.clear();

        listView_notes.setAdapter(itemAdapter);
        listView_notes.setEmptyView(findViewById(R.id.textView_empty_text));

    }

    public void click_short_Listener(){

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this ,New_noteActivity.class);
                intent.putExtra("requestCode",NOTE_ADD);
                startActivityForResult(intent, NOTE_ADD);
            }
        });

        listView_notes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            // 參數1是使用者操作的ListView物件
            // 參數2是使用者選擇的項目
            // 參數3是使用者選擇的項目編號，第一個是0
            // 參數4在這裡沒有用途
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (!long_listener) {
                    Note_item item = itemAdapter.getItem(position);

                    if (selectClick) {

                        item.setSelect(!item.getSelect());
                        itemAdapter.set(position, item);
                        itemAdapter.notifyDataSetChanged();

                        if (item.getSelect()) choice_count++;
                        else choice_count--;
                        choice_number.setText(String.valueOf(choice_count));

                    } else
                    {
                        if (item.getTitle().compareTo("_noTitle_") == 0) item.setTitle("");

                        Intent intent = new Intent(MainActivity.this ,New_noteActivity.class);
                        intent.putExtra("position", position);
                        intent.putExtra("myItem", item);
                        intent.putExtra("requestCode",NOTE_MODIFY);
                        startActivityForResult(intent, NOTE_MODIFY);
                    }
                } else long_listener = false;
            }
        });
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectClick) {
                    selectClick = false;
                    //changeMenu.clear();
                    //onCreateOptionsMenu(changeMenu);
                    invalidateOptionsMenu();
                } else
                    drawer.openDrawer(GravityCompat.START);
            }
        });
    }
    public void click_long_Listener(){

        listView_notes.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                long_listener = true;

                search_to_select = is_search;
                selectClick = true;
                changeMenu.clear();
                onCreateOptionsMenu(changeMenu);
                //invalidateOptionsMenu();

                Note_item item = itemAdapter.getItem(position);
                item.setSelect(true);
                itemAdapter.set(position, item);
                itemAdapter.notifyDataSetChanged();

                choice_count = 1;
                choice_number.setText(String.valueOf(choice_count));

                return false;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        itemDAO = new Item_DAO(this);    //open database

        switch (resultCode){
            case NOTE:
                Note_item item = (Note_item)data.getSerializableExtra("myItem");

                if(TextUtils.isEmpty( item.getTitle() ) ){
                    item.setTitle("_noTitle_");
                }

                if(requestCode==NOTE_ADD) {
                    item.setLabel("Diary");

                    item = itemDAO.insert(item);            //insert itemId with database_id
                    sort_All(sortWay,null);                 //list item
                }
                else
                if(requestCode==NOTE_MODIFY){

                    int position = data.getIntExtra("position", -1);
                    if(position!=-1)
                    {
                        itemDAO.update(item);               //updata database
                        itemAdapter.set(position, item);    //updata list item
                    }
                }
                itemAdapter.notifyDataSetChanged();

                break;
        }
    }

    @Override
    public void onBackPressed(){         //back press
        if(selectClick){
            selectClick = false;
            invalidateOptionsMenu();
        }else
        if( drawer.isDrawerOpen(GravityCompat.START) )
            drawer.closeDrawer(GravityCompat.START);
        else
            super.onBackPressed();
    }

    @Override
    protected void onRestart(){
        itemDAO = new Item_DAO(this);
        super.onRestart();
    }

    @Override
    protected void onStop(){
        itemDAO.close();
        super.onStop();
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        if(selectClick)
        {
            getMenuInflater().inflate(R.menu.menu_select, menu);
            getSupportActionBar().setDisplayShowTitleEnabled(false);                //cancel actionbartitle
            toolbar.setNavigationIcon(R.drawable.check_done_24);

            fab.setVisibility(View.INVISIBLE);
            itemAdapter.setSelectLook(true, false);

            menu.findItem(R.id.select_allChoice).setVisible(!search_to_select);
            menu.findItem(R.id.select_allCancel).setVisible(!search_to_select);
        } else
        {
            getSupportActionBar().setDisplayShowTitleEnabled(true);

            fab.setVisibility(View.VISIBLE);
            itemAdapter.setSelectLook(false, false);
            search_to_select = false;
            sort_All(sortWay, null);
        }
        changeMenu = menu;
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected( MenuItem item){
        switch (item.getItemId()) {
            case R.id.item_delete:
                if(choice_count==0)
                    Toast.makeText(this, "You did not choose anything", Toast.LENGTH_SHORT).show();
                else
                {
                    AlertDialog.Builder builder= new AlertDialog.Builder(this);
                    builder.setTitle("Warning").setMessage("Select "+choice_count+" note , are you sure to delete?");

                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            Note_item item;

                            for(int i=itemAdapter.getCount()-1; i>=0 ;i--){
                                item = itemAdapter.getItem(i);

                                if(item.getSelect()){
                                    itemDAO.delete(item);               //delete note
                                    itemAdapter.remove(i);
                                }
                            }
                            itemAdapter.notifyDataSetChanged();
                            Toast.makeText(MainActivity.this,"Already deleted "+String.valueOf(choice_count)+" note", Toast.LENGTH_SHORT).show();

                            choice_count=0;
                            choice_number.setText(String.valueOf(choice_count));
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    builder.create().show();
                }
                break;

            case R.id.change_title:
                if(choice_count!=1 )
                    Toast.makeText(this, "Please only select one file",Toast.LENGTH_SHORT).show();
                else
                {
                    AlertDialog.Builder builder= new AlertDialog.Builder(this);
                    builder.setTitle("Enter your title : ");
                    final EditText Title = new EditText(MainActivity.this);
                    builder.setView(Title);

                    Note_item it;
                    //reset original title
                    for(int i=0;i<itemAdapter.getCount();i++) {
                        it = itemAdapter.getItem(i);
                        if(it.getSelect()){
                            Title.setText(it.getTitle());
                            break;
                        }
                    }
                    builder.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();

                            set_change(changeTitle, 0, Title.getText().toString() ,0);
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    builder.create().show();
                }
                break;

            case R.id.change_label:
                if(choice_count==0 )
                    Toast.makeText(this, "You did not choose anything",Toast.LENGTH_SHORT).show();
                else
                {
                    final String items[] ={"Diary" ,"Note" ,"Reminder"};
                    AlertDialog.Builder builder= new AlertDialog.Builder(this);
                    builder.setTitle("Please choose your label");
                    builder.setItems(items, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            set_change(changeLabel, 0, items[which] ,0);
                        }
                    });

                    builder.create().show();
                }
                break;

            case R.id.change_datetime:
                if(choice_count!=1 )
                    Toast.makeText(this, "Please only select one file",Toast.LENGTH_SHORT).show();
                else
                {
                    final Calendar calendar = Calendar.getInstance();           //set data today
                    int Year = calendar.get(Calendar.YEAR);
                    int Month = calendar.get(Calendar.MONTH);
                    int Day = calendar.get(Calendar.DAY_OF_MONTH);

                    DatePickerDialog datepicker =new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int month, int day) {
                            calendar.set(year,month,day,10,10,10);
                            Date dt =calendar.getTime();

                            set_change(changeDatetime ,0 ,null ,dt.getTime());
                        }
                    },Year,Month,Day);

                    datepicker.show();
                }
                break;

            case R.id.select_allChoice:
                itemAdapter.setSelectLook(true , true);

                choice_count = itemDAO.getAll_Count();                  //total notes count
                choice_number.setText(String.valueOf(choice_count));
                break;
            case R.id.select_allCancel:
                itemAdapter.setSelectLook(true , false);

                choice_count=0;
                choice_number.setText(String.valueOf(choice_count));
                break;
        }
        return true;
    }


    public void set_change(int set ,int star , String string , long date){
        Note_item item ;

        for(int i=0; i < itemAdapter.getCount();i++)
        {
            item = itemAdapter.getItem(i);
            if(item.getSelect())
            {
                switch (set){
                    case changeTitle:
                        item.setTitle(string);
                        break;
                    case changeLabel:
                        item.setLabel(string);
                        break;
                    case changeDatetime:
                        item.setDatetime(date);
                        break;
                }
                itemAdapter.set(i, item);
                itemDAO.update(item);                               //updata DB

                if(set==changeTitle || set==changeDatetime) break;
            }
        }
        itemAdapter.notifyDataSetChanged();
    }

    public void sort_All(int sortWay ,String search_text){

        List<Note_item> list_item = new ArrayList<>();
        itemAdapter.removeClear();
        int type;

        switch (sortWay){
            case sort_date :
                list_item = itemDAO.get_sortDate();
                type = TYPE_DATE;
                break;
            default:    type=TYPE_CONTENT;
        }
        for(int i=0 ; i<list_item.size() ; i++) {
            itemAdapter.add(list_item.get(i) , type);
        }

        itemAdapter.notifyDataSetChanged();
        list_item.clear();
    }

}
