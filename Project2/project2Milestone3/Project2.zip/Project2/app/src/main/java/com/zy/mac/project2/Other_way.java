package com.zy.mac.project2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class Other_way {


    public  byte[] Bitmap_to_Bytes(Bitmap bm) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, baos);
        return baos.toByteArray();
    }


    public static Bitmap scalePicture(String filename, int maxWidth,int maxHeight) {
        Bitmap bitmap = null;
        try {
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(filename, opts);
            int srcWidth = opts.outWidth;
            int srcHeight = opts.outHeight;
            int desWidth = 0;
            int desHeight = 0;
            double ratio = 0.0;
            if (srcWidth > srcHeight) {
                ratio = srcWidth / maxWidth;
                desWidth = maxWidth;
                desHeight = (int) (srcHeight / ratio);
            } else {
                ratio = srcHeight / maxHeight;
                desHeight = maxHeight;
                desWidth = (int) (srcWidth / ratio);
            }
            // height&width
            BitmapFactory.Options newOpts = new BitmapFactory.Options();
            newOpts.inSampleSize = (int) (ratio) + 1;
            newOpts.inJustDecodeBounds = false;
            newOpts.outWidth = desWidth;
            newOpts.outHeight = desHeight;
            bitmap = BitmapFactory.decodeFile(filename, newOpts);

        } catch (Exception e) {
            // TODO: handle exception
        }
        return bitmap;
    }


    public Bitmap compressImageSize(String path, int size ,Context context) throws IOException {
        // get ima
        InputStream temp = context.getAssets().open(path);
        BitmapFactory.Options options = new BitmapFactory.Options();
        // save space
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(temp, null, options);
        temp.close();


        int i = 0;
        Bitmap bitmap = null;
        while (true) {
            if ((options.outWidth >> i <= size) && (options.outHeight >> i <= size)) {
                temp = context.getAssets().open(path);
                options.inSampleSize = (int) Math.pow(2.0D, i);
                options.inJustDecodeBounds = false;

                bitmap = BitmapFactory.decodeStream(temp, null, options);
                break;
            }
            i += 1;
        }
        return bitmap;
    }
}
