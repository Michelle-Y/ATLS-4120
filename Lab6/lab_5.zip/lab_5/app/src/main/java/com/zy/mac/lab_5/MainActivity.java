package com.zy.mac.lab_5;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {
//    private CheckBox;
    public RadioButton radioButtonBoy, radioButtonGirl;
    private String string = new String();
    private Set<String> set = new HashSet<String>();
    private TextView textView;
    public EditText editText;
    public String citytravel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        initText();
    }
    public void initText() {
        if (radioButtonGirl.isChecked()) {
            string ="It is better to travel ten thousand miles than to read ten thousand books.";
        } else {
            string="Books are a uniquely portable magic.";
        }

    }
    public void initViews() {
        textView = (TextView) findViewById(R.id.tv_result);
        radioButtonBoy = findViewById(R.id.boy);
        radioButtonGirl = (RadioButton) findViewById(R.id.girl);
        radioButtonBoy.setOnCheckedChangeListener(this);
        radioButtonGirl.setOnCheckedChangeListener(this);
        editText = (EditText) findViewById(R.id.editText);
    }
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.boy:
                if (isChecked) {
                    string="Books are a uniquely portable magic. ";
                    ImageView fox = findViewById(R.id.imageView);
                    fox.setImageResource(R.drawable.fox);
                    citytravel = "Library";
                }
                break;
            case R.id.girl:
                if (isChecked) {
                    string="It is better to travel ten thousand miles than to read ten thousand books. ";
                    ImageView travel = findViewById(R.id.imageView);
                    travel.setImageResource(R.drawable.travel);
                }
                break;
        }
    }
    public void commit(View view) {
        RadioGroup check = findViewById(R.id.radioGroup);
        int check_id = check.getCheckedRadioButtonId();
        EditText nameValue = findViewById(R.id.editText);
        String nameText = nameValue.getText().toString();
        CheckBox springCheckBox = findViewById(R.id.checkBox);
        CheckBox summerCheckBox = findViewById(R.id.checkBox2);
        CheckBox fallCheckBox = findViewById(R.id.checkBox3);
        CheckBox winterCheckBox = findViewById(R.id.checkBox4);
        Boolean winter = winterCheckBox.isChecked();
        Boolean spring = springCheckBox.isChecked();
        Boolean summer = summerCheckBox.isChecked();
        Boolean fall = fallCheckBox.isChecked();

        if (check_id == -1){
            Context context = getApplicationContext();
            CharSequence text = "Loading your prefer";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
//        }
//        else {
                if (spring) {
                    citytravel = "London";
                }
                if (summer) {
                    citytravel = "St.Barts";
                }
                if (fall) {
                    citytravel = "Montreal";
                }
                if (winter) {
                    citytravel = "Amalfi Coast";
                }

        }


        set.add(nameText);
        textView.setText(string.toString() + "My favorite is " + set.toString() + " Suggest Place to go: " + citytravel);
    }
}
